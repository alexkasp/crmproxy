/* libs/esl/src/include/esl_config_auto.h.  Generated from esl_config_auto.h.in by configure.  */
/* Define to 1 if you have libedit available */
#define HAVE_LIBEDIT 1

/* Define to 1 if you have the declaration `EL_PROMPT_ESC', and to 0
   if you don't. */
#define HAVE_DECL_EL_PROMPT_ESC 0

/* Define to 1 if you have the declaration `EL_REFRESH', and to 0 if
   you don't. */
#define HAVE_DECL_EL_REFRESH 1

/* Define to 1 if you have the `el_wset' function. */
/* #undef HAVE_EL_WSET */
